import javax.swing.*;

public class EmprestimoException extends Exception{
    public EmprestimoException(){
        JOptionPane.showMessageDialog(null,"Contate seu gerente: 0800 726 0101");
    }
}
