import javax.swing.*;

public class SaqueException extends Exception{
    public SaqueException(){
        JOptionPane.showMessageDialog(null,"Vai Trabalhar");
    }
}
